﻿select * from agv where AGVNumber = 102
select * from tag where agvid = 7